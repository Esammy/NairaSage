# Curriculum hooks
