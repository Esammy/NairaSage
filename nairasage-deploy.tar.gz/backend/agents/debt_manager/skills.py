from agents.skills.financial_math import debt_payoff_schedule
