# Portfolio analytics hooks
