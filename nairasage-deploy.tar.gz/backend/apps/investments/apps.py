from django.apps import AppConfig


class InvestmentsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.investments"
    label = "investments"

    def ready(self):
        import apps.investments.signals  # noqa: F401
